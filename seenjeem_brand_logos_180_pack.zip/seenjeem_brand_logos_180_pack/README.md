# SeenJeem Brand Logos 180 Pack

CategoryId: 44
Category: شعارات شركات

Content:
- 180 questions
- 60 Easy
- 60 Medium
- 60 Hard

Recommended workflow:
1. Delete old category 44 questions:
   DELETE FROM Questions WHERE CategoryId = 44;

2. Copy these files beside package.json in Angular root:
   - download_brand_logos_180.ps1
   - brand_logos_180_manifest.json

3. Run PowerShell:
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\download_brand_logos_180.ps1

4. Import:
   brand_logo_questions_180_category_44_local_paths.json

Images will be saved to:
public/assets/question-images/brand-logos-180

Question paths are:
assets/question-images/brand-logos-180/brand_001.svg
...
assets/question-images/brand-logos-180/brand_180.svg

Notes:
- Icons are downloaded from Simple Icons via jsDelivr.
- Simple Icons provides SVG icons for popular brands.
- Brand names/logos may still be trademarks of their owners.
